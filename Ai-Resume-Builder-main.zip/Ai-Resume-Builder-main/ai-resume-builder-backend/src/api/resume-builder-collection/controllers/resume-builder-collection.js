'use strict';

/**
 * resume-builder-collection controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::resume-builder-collection.resume-builder-collection');
